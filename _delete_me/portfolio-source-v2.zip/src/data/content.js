/* ============================================================================
   SINGLE SOURCE OF TRUTH FOR ALL PORTFOLIO CONTENT
   ----------------------------------------------------------------------------
   Everything on the site reads from this file. Edit here, nowhere else.
   Facts below come from your résumé + LinkedIn. Anything marked // TODO
   still needs you.
   ========================================================================== */

export const profile = {
  name: 'Manikandan R',
  firstName: 'Manikandan',
  pronouns: 'He/Him',
  role: 'Senior Software Developer',
  headline: 'Full-Stack & ERP Architect',
  tagline:
    'Five years turning operational messes into software people actually use — mobile, web and the ERP underneath.',
  location: 'Sholinganallur, Chennai',
  company: 'Vivid Trans Tech Solutions India',
  availability: 'Open to select freelance & consulting work', // TODO adjust or set to ''
  rotating: ['Flutter', 'React', 'Node.js', 'ERPNext', 'MySQL'],
}

export const about = {
  intro:
    'I build cross-platform products and the systems that run behind them. Right now that means full-stack ERPNext work and a React/Node ERP for the Tamil Nadu MTC transport department; before that, seven Flutter apps across education, traffic policing, CRM, lead marketplaces and field operations.',
  body: [
    'I did not come into engineering through a computer science degree. I read History at Presidency College, spent two and a half years running creative direction for events, then a year in logistics — and moved into backend support in 2021 because the systems were more interesting than the spreadsheets around them.',
    'That route left a mark on how I work. I have sat on the operations side of bad software, so I start from the workflow and the data model rather than the screen. Most of what I have shipped replaced a paper process or an Excel file that somebody was quietly terrified of.',
    'The through line across every one of them is the same: understand the actual operation, model it properly, then make the interface disappear. Attendance rates up 15%, administrative processing down 20%, asset maintenance costs down 10% — those came from getting the workflow right, not from clever code.',
  ],
  stats: [
    { value: '5+', label: 'Years building software' },
    { value: '7+', label: 'Projects delivered' },
    { value: '20%', label: 'Admin time removed (MSMS)' },
    { value: '15%', label: 'Attendance lift (MSMS)' },
  ],
  education: {
    degree: 'B.A. History',
    school: 'Presidency College, Chennai',
    years: '2015 — 2018',
  },
  languages: ['Tamil', 'English', 'Telugu'],
  interests: ['Mobile app development trends', 'Open source contribution', 'History & cultural studies'],
}

/* ---------------------------------------------------------------- experience */
export const experience = [
  {
    role: 'Senior Software Developer',
    company: 'Vivid Trans Tech Solutions India',
    type: 'Full-time · On-site',
    period: 'Aug 2025 — Present',
    duration: '1 yr 1 mo',
    current: true,
    summary:
      'Full-stack and ERP architecture — ERPNext/Frappe customisation alongside a React + Node.js ERP for the Tamil Nadu MTC transport department.',
    highlights: [
      'Building an ERP for the TN MTC transport department: React front-end, Node.js services, SQL data model.',
      'Full-stack ERPNext / Frappe work — custom doctypes, workflows, server scripts and reports.',
      'Own features end to end, from schema design through shipped interface.',
    ],
    stack: ['ERPNext', 'Frappe', 'React', 'Node.js', 'Python', 'SQL'],
  },
  {
    role: 'Flutter Developer',
    company: 'ELK Education Consultants Pvt Ltd',
    type: 'Full-time · On-site',
    period: 'Mar 2024 — Aug 2025',
    duration: '1 yr 6 mos',
    summary:
      'Flutter applications for the education sector, delivered in Scrum with disciplined version control.',
    highlights: [
      'Shipped multi-role education platforms with five distinct login types.',
      'Integrated REST and third-party APIs, payment gateways and push notifications.',
      'Worked sprint to sprint in Scrum with release-branch discipline.',
    ],
    stack: ['Flutter', 'Dart', 'MySQL', 'REST APIs', 'Scrum'],
  },
  {
    role: 'Flutter Developer',
    company: 'Bonton Softwares Pvt. Ltd.',
    type: 'Full-time · On-site',
    period: 'Jan 2022 — Mar 2024',
    duration: '2 yrs 3 mos',
    summary:
      'Moved from backend into mobile and became the delivery point for client-facing Flutter apps across CRM, traffic policing and field operations.',
    highlights: [
      'Delivered production Flutter apps from requirement to store release.',
      'Integrated Stripe and other payment gateways, Google Maps and Google APIs.',
      'Built Firebase and OneSignal push notification pipelines.',
      'Translated client requirements directly into technical plans and MVPs.',
    ],
    stack: ['Flutter', 'Dart', 'Firebase', 'MVVM', 'Stripe', 'Google Maps'],
  },
  {
    role: 'Backend Support Executive',
    company: 'Bonton Softwares Pvt. Ltd.',
    type: 'Full-time · On-site',
    period: 'Feb 2021 — Jan 2022',
    duration: '1 yr',
    summary:
      'First engineering role — production database support, where the SQL habits came from.',
    highlights: [
      'Diagnosed and resolved production data issues in MySQL.',
      'Wrote and optimised queries and reports for internal teams.',
    ],
    stack: ['MySQL', 'SQL optimisation'],
  },
  {
    role: 'Logistics Executive',
    company: 'Butterfly Gandhimathi Appliances',
    type: 'Full-time · Hybrid',
    period: 'Feb 2020 — Dec 2020',
    duration: '11 mos',
    summary:
      'Coordinated operations and logistics across teams and vendors — the operations-side view I still design software from.',
    highlights: [],
    stack: ['Operations', 'Coordination'],
  },
  {
    role: 'Creative Director',
    company: 'Maitreya Events',
    type: 'Self-employed',
    period: 'Aug 2017 — Jan 2020',
    duration: '2 yrs 6 mos',
    summary: 'Design direction and strategic creative development for events.',
    highlights: [],
    stack: ['Design direction', 'Creative strategy', 'Branding'],
  },
]

/* -------------------------------------------------------------------- skills */
export const skillGroups = [
  {
    title: 'Mobile',
    accent: '#22d3ee',
    skills: [
      { name: 'Flutter', level: 95 },
      { name: 'Dart', level: 92 },
      { name: 'MVVM / MVP architecture', level: 88 },
      { name: 'Play Store / App Store release', level: 82 },
    ],
  },
  {
    title: 'Web & ERP',
    accent: '#8b5cf6',
    skills: [
      { name: 'ERPNext / Frappe', level: 85 },
      { name: 'React', level: 84 },
      { name: 'Node.js', level: 82 },
      { name: 'Python', level: 75 },
    ],
  },
  {
    title: 'Data & Integrations',
    accent: '#f472b6',
    skills: [
      { name: 'MySQL & SQL optimisation', level: 90 },
      { name: 'REST & third-party APIs', level: 90 },
      { name: 'Payment gateways (Stripe)', level: 85 },
      { name: 'Firebase · OneSignal · Google APIs', level: 88 },
    ],
  },
  {
    title: 'Platform & Practice',
    accent: '#a3e635',
    skills: [
      { name: 'Git & version control', level: 90 },
      { name: 'CI/CD — Jenkins, GitLab CI', level: 72 },
      { name: 'AWS / Google Cloud', level: 68 },
      { name: 'Scrum & requirement analysis', level: 88 },
    ],
  },
]

/* ------------------------------------------------------------------ projects */
/* All real, from your résumé + current role.
   Optional fields you can add to any project: `company`, `year`, and
   `links: { live, repo }` — the card renders them only when filled in. */
export const projects = [
  {
    title: 'TN MTC Transport ERP',
    subtitle: 'React · Node.js · SQL',
    blurb:
      'ERP for the Tamil Nadu Metropolitan Transport Corporation — a full React front-end over Node.js services, digitising depot and fleet operations for a state transport department.',
    features: [
      'React front-end over Node.js APIs and a relational data model',
      'Depot and fleet operations workflows',
      'Role-based access across departmental users',
    ],
    metrics: [
      { k: 'Client', v: 'TN MTC · Govt.' },
      { k: 'Role', v: 'Full-stack developer' },
    ],
    tags: ['React', 'Node.js', 'SQL', 'ERP'],
    accent: '#22d3ee',
    featured: true,
    current: true,
  },
  {
    title: 'ERPNext Implementations',
    subtitle: 'Frappe · Python · MariaDB',
    blurb:
      'Full-stack ERPNext and Frappe work — custom doctypes, workflows, server scripts and reporting built on top of the platform for live business operations.',
    features: [
      'Custom doctypes and workflow automation',
      'Server scripts, hooks and scheduled jobs',
      'Reporting and query design over the ERP data model',
    ],
    metrics: [
      { k: 'Platform', v: 'ERPNext / Frappe' },
      { k: 'Role', v: 'Full-stack developer' },
    ],
    tags: ['ERPNext', 'Frappe', 'Python', 'SQL'],
    accent: '#8b5cf6',
    featured: true,
    current: true,
  },
  {
    title: 'MSMS — Model School Management System',
    subtitle: 'Flutter · MySQL · REST',
    blurb:
      'A school operations platform with five separate login types — school, state, teacher, headmaster and hostel — covering admissions, attendance, hostel life, food services and assets.',
    features: [
      '5 role-based login types with distinct permissions',
      'Attendance tracking — 15% improvement in attendance rates',
      'Leave request approvals — 20% less administrative processing time',
      'Asset management — 10% reduction in maintenance costs',
      'Admissions, class assignment and food services modules',
    ],
    metrics: [
      { k: 'Logins', v: '5 role types' },
      { k: 'Impact', v: '+15% attendance' },
    ],
    tags: ['Flutter', 'MySQL', 'Multi-role', 'Reporting'],
    accent: '#f472b6',
    featured: true,
  },
  {
    title: 'Study Place',
    subtitle: 'Flutter · Firebase · REST',
    blurb:
      'A study companion built around one idea: never make a student leave the material to take a note. Digital library, video lessons, question papers and tests, with note-taking woven through all of it.',
    features: [
      'Digital library with folder-based organisation of study material',
      'In-built note-taking while reading books or watching lessons',
      'Question paper access, test writing and submission',
      'Performance evaluation from previous test results',
      'Study-hour and progress tracking reports',
    ],
    metrics: [
      { k: 'Domain', v: 'EdTech' },
      { k: 'Role', v: 'Flutter developer' },
    ],
    tags: ['Flutter', 'Video', 'Offline notes', 'Analytics'],
    accent: '#a3e635',
  },
  {
    title: 'Smart Traffic Kavalar',
    subtitle: 'Flutter · Google Maps · Sensors',
    blurb:
      'Field application for traffic police: real-time accident tracking, personnel attendance and work assignment, VIP route allocation and sensor-fed vehicle detection.',
    features: [
      'Real-time accident tracking and incident management',
      'Attendance and work assignment for traffic control personnel',
      'VIP route allocation and optimisation',
      'Vehicle detection and classification via sensors and cameras',
    ],
    metrics: [
      { k: 'Users', v: 'Traffic police' },
      { k: 'Role', v: 'Flutter developer' },
    ],
    tags: ['Flutter', 'Google Maps', 'Real-time', 'Govt.'],
    accent: '#38bdf8',
  },
  {
    title: 'Rapid Collaborate',
    subtitle: 'Flutter · Firebase · REST',
    blurb:
      'Client-facing project and support platform — projects, queries and a full ticketing system, with fifteen new form types designed and built for their intake flows.',
    features: [
      '15 new form types designed and implemented',
      'Project and query management',
      'Support ticket lifecycle handling',
      'Firebase real-time push notifications',
    ],
    metrics: [
      { k: 'Forms', v: '15 types built' },
      { k: 'Role', v: 'Flutter developer' },
    ],
    tags: ['Flutter', 'Firebase', 'Ticketing', 'Forms'],
    accent: '#c084fc',
  },
  {
    title: 'Emarketz — Leads Panel',
    subtitle: 'Flutter · Payment gateway · OneSignal',
    blurb:
      'Lead marketplace and wallet: sourcing and purchasing leads, tagging and categorisation, gateway payments and a reviewable financial history.',
    features: [
      'Lead acquisition, sourcing and purchase flows',
      'Tag-based lead categorisation and management',
      'Payment gateway transactions and wallet handling',
      'Payment history review and reconciliation',
      'OneSignal push notification delivery',
    ],
    metrics: [
      { k: 'Domain', v: 'Sales / leads' },
      { k: 'Role', v: 'Flutter developer' },
    ],
    tags: ['Flutter', 'Payments', 'Wallet', 'OneSignal'],
    accent: '#fb923c',
  },
  {
    title: 'Insta CRM — Support App',
    subtitle: 'Flutter · REST · Templates',
    blurb:
      'Support desk in your pocket: a metrics dashboard, ten query detail types, and reusable email and WhatsApp templates so agents stop retyping the same replies.',
    features: [
      'Support metrics dashboard',
      '10 types of query detail views',
      'Email and WhatsApp template builders',
      'Payment detail lookups',
    ],
    metrics: [
      { k: 'Queries', v: '10 detail types' },
      { k: 'Role', v: 'Flutter developer' },
    ],
    tags: ['Flutter', 'CRM', 'Templates'],
    accent: '#facc15',
  },
  {
    title: 'ECO Park',
    subtitle: 'Flutter · Payments · Ticketing',
    blurb:
      'Visitor app for a public park — entry ticket purchase, park information and event coordination in one place.',
    features: [
      'Entry ticket purchase with payment integration',
      'Park overview, details and features',
      'Event listings and coordination',
    ],
    metrics: [
      { k: 'Domain', v: 'Public / leisure' },
      { k: 'Role', v: 'Flutter developer' },
    ],
    tags: ['Flutter', 'Ticketing', 'Payments'],
    accent: '#34d399',
  },
]

/* -------------------------------------------------------------- testimonials */
/* TODO: replace with real quotes from your LinkedIn recommendations.
   Delete this array entirely (set it to []) and the section disappears. */
export const testimonials = [
  {
    quote:
      'Placeholder quote — paste a real recommendation here. Short, specific quotes about how someone works land much harder than generic praise.',
    name: 'Name Surname',
    title: 'Engineering Manager',
    company: 'Company',
    placeholder: true,
  },
  {
    quote:
      'Placeholder quote — a line from a manager or client naming a shipped project and its outcome is the strongest version of this section.',
    name: 'Name Surname',
    title: 'Product Owner',
    company: 'Company',
    placeholder: true,
  },
  {
    quote:
      'Placeholder quote — if you have no written recommendations yet, ask two former colleagues on LinkedIn. It takes them five minutes.',
    name: 'Name Surname',
    title: 'Senior Developer',
    company: 'Company',
    placeholder: true,
  },
]

/* ------------------------------------------------------------------- contact */
export const contact = {
  email: 'chemanishazad@gmail.com',
  phone: '+91 87781 45196',
  website: 'https://www.chemanishazad.com',
  resume: '/Manikandan-R-Resume.pdf', // drop your PDF into /public with this name
  socials: [
    {
      label: 'LinkedIn',
      href: 'https://www.linkedin.com/in/manikandan-r-flutter/',
      handle: '/in/manikandan-r-flutter',
    },
    { label: 'GitHub', href: '', handle: 'add your GitHub URL' }, // TODO
    { label: 'Website', href: 'https://www.chemanishazad.com', handle: 'chemanishazad.com' },
    { label: 'Phone', href: 'tel:+918778145196', handle: '+91 87781 45196' },
  ],
}

export const nav = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'projects', label: 'Work' },
  { id: 'experience', label: 'Career' },
  { id: 'skills', label: 'Skills' },
  { id: 'voices', label: 'Voices' },
  { id: 'contact', label: 'Contact' },
]
