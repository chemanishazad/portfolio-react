import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { profile } from '../data/content'

export default function Loader() {
  const [pct, setPct] = useState(0)
  const [done, setDone] = useState(false)

  useEffect(() => {
    let v = 0
    const tick = setInterval(() => {
      // Ease toward 100 so it never stalls at a hard number.
      v += Math.max(1.5, (100 - v) * 0.11)
      if (v >= 100) {
        v = 100
        clearInterval(tick)
        setTimeout(() => setDone(true), 380)
      }
      setPct(Math.round(v))
    }, 55)
    return () => clearInterval(tick)
  }, [])

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          exit={{ opacity: 0 }}
          transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-[90] grid place-items-center bg-ink-900"
        >
          <div className="w-[min(78vw,420px)]">
            <div className="mb-5 flex items-end justify-between">
              <span className="font-display text-sm font-medium tracking-tight text-white/80">
                {profile.name}
              </span>
              <span className="font-mono text-xs text-neon-cyan/80">{pct}%</span>
            </div>
            <div className="h-[2px] w-full overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-neon-cyan via-neon-violet to-neon-pink transition-[width] duration-100"
                style={{ width: pct + '%' }}
              />
            </div>
            <p className="mt-5 font-mono text-[10.5px] uppercase tracking-[0.28em] text-white/25">
              Compiling scene…
            </p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
