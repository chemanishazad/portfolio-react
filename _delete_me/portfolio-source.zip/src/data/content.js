/* ============================================================================
   SINGLE SOURCE OF TRUTH FOR ALL PORTFOLIO CONTENT
   ----------------------------------------------------------------------------
   Everything on the site reads from this file. Edit here, nowhere else.
   Anything marked  // TODO  is a placeholder for you to fill in.
   ========================================================================== */

export const profile = {
  name: 'Manikandan R',
  firstName: 'Manikandan',
  pronouns: 'He/Him',
  role: 'Senior Software Developer',
  headline: 'Full-Stack & ERP Architect',
  tagline: 'I build cross-platform products and the ERP backbones that run them.',
  location: 'Chennai, Tamil Nadu, India',
  company: 'Vivid Trans Tech Solutions India',
  availability: 'Open to select freelance & consulting work', // TODO adjust
  // Rotating words in the hero headline
  rotating: ['Flutter', 'React', 'Node.js', 'Frappe / ERPNext', 'SQL & ORM'],
}

export const about = {
  intro:
    'I am a Senior Software Developer based in Chennai, working across the full stack — from Flutter apps that ship to thousands of devices to the Frappe/ERPNext systems and Node.js services behind them.',
  body: [
    'My path into engineering was not the usual one. I spent close to three years running creative direction for events before moving into backend support in 2021, then into Flutter development. That mix is still how I work: I care as much about how an interface feels as about how the schema underneath it is modelled.',
    'Over the last five years I have moved from backend support into mobile development and then into architecture — designing data models, wiring ERP workflows, and owning features end to end rather than in slices.',
    'Today I focus on the seam between product and platform: cross-platform Flutter front-ends, React web apps, Node.js APIs, and ERP customisation on Frappe/ERPNext, with SQL and ORM design tying it together.',
  ],
  stats: [
    { value: '5+', label: 'Years building software' },
    { value: '4', label: 'Companies shipped for' },
    { value: '1.5K+', label: 'LinkedIn followers' },
    { value: '∞', label: 'Hot refreshes' },
  ],
}

/* ---------------------------------------------------------------- experience */
export const experience = [
  {
    role: 'Senior Software Developer',
    company: 'Vivid Trans Tech Solutions India',
    type: 'Full-time · On-site',
    period: 'Aug 2025 — Present',
    duration: '1 yr 1 mo',
    current: true,
    summary:
      'Architecting full-stack and ERP systems — Flutter and React front-ends over Node.js services and Frappe/ERPNext back-ends.',
    highlights: [
      'Own feature delivery end to end, from data model to shipped UI.', // TODO make specific
      'Design ORM and SQL layers for reporting and ERP workflows.', // TODO
      'Set front-end architecture patterns for cross-platform delivery.', // TODO
    ],
    stack: ['Flutter', 'React', 'Node.js', 'Frappe/ERPNext', 'SQL'],
  },
  {
    role: 'Flutter Developer',
    company: 'ELK Education Consultants Pvt Ltd',
    type: 'Full-time · On-site',
    period: 'Mar 2024 — Aug 2025',
    duration: '1 yr 6 mos',
    summary:
      'Built and maintained Flutter applications for the education-consulting domain, working in Scrum with disciplined version control.',
    highlights: [
      'Delivered cross-platform features against sprint commitments.', // TODO
      'Worked in Scrum ceremonies with a distributed review culture.',
      'Maintained release branches and version-control hygiene.',
    ],
    stack: ['Flutter', 'Dart', 'Scrum', 'Git'],
  },
  {
    role: 'Flutter Developer',
    company: 'Bonton Softwares Pvt. Ltd.',
    type: 'Full-time · On-site',
    period: 'Jan 2022 — Mar 2024',
    duration: '2 yrs 3 mos',
    summary:
      'Moved from backend into mobile, building production Flutter apps and growing into feature ownership.',
    highlights: [
      'Shipped Flutter applications from design hand-off to store release.', // TODO
      'Bridged mobile clients to existing SQL back-ends.', // TODO
      'Mentored on Flutter patterns and state management.', // TODO
    ],
    stack: ['Flutter', 'Dart', 'REST APIs', 'MySQL'],
  },
  {
    role: 'Backend Support',
    company: 'Bonton Softwares Pvt. Ltd.',
    type: 'Full-time · On-site',
    period: 'Feb 2021 — Jan 2022',
    duration: '1 yr',
    summary:
      'First engineering role — supporting production databases and learning the systems side of the product.',
    highlights: [
      'Diagnosed and resolved production data issues in MySQL.',
      'Wrote queries and reports for internal teams.', // TODO
    ],
    stack: ['MySQL', 'Databases'],
  },
  {
    role: 'Logistics Coordinator',
    company: 'Butterfly Group',
    type: 'Full-time · Hybrid',
    period: 'Feb 2020 — Dec 2020',
    duration: '11 mos',
    summary: 'Coordinated operations and logistics across teams and vendors.',
    highlights: [],
    stack: ['Operations', 'Coordination'],
  },
  {
    role: 'Creative Director',
    company: 'Maitreya Events',
    type: 'Self-employed',
    period: 'Aug 2017 — Jan 2020',
    duration: '2 yrs 6 mos',
    summary:
      'Design direction and strategic creative development for events — the design instinct I still bring to product work.',
    highlights: [],
    stack: ['Design Direction', 'Creative Strategy', 'Branding'],
  },
]

/* -------------------------------------------------------------------- skills */
export const skillGroups = [
  {
    title: 'Mobile',
    accent: '#22d3ee',
    skills: [
      { name: 'Flutter', level: 95 },
      { name: 'Dart', level: 92 },
      { name: 'State Management (Bloc / Riverpod)', level: 85 },
      { name: 'Play Store / App Store release', level: 80 },
    ],
  },
  {
    title: 'Web & Front-end',
    accent: '#8b5cf6',
    skills: [
      { name: 'React', level: 85 },
      { name: 'JavaScript / TypeScript', level: 84 },
      { name: 'HTML & CSS', level: 88 },
      { name: 'Responsive UI systems', level: 86 },
    ],
  },
  {
    title: 'Backend & Data',
    accent: '#f472b6',
    skills: [
      { name: 'Node.js', level: 82 },
      { name: 'SQL / MySQL', level: 88 },
      { name: 'ORM design', level: 80 },
      { name: 'REST API design', level: 86 },
    ],
  },
  {
    title: 'ERP & Platform',
    accent: '#a3e635',
    skills: [
      { name: 'Frappe / ERPNext', level: 85 },
      { name: 'Python', level: 75 },
      { name: 'Git & version control', level: 90 },
      { name: 'Scrum / Agile delivery', level: 85 },
    ],
  },
]

/* ------------------------------------------------------------------ projects */
/* TODO: replace all four with your real projects. Keep the same shape.
   `image` is optional — drop a file in /public and set image: '/my-shot.png' */
export const projects = [
  {
    title: 'ERP Mobile Companion',
    subtitle: 'Flutter · Frappe/ERPNext · REST',
    year: '2026',
    blurb:
      'A Flutter companion app that puts ERPNext workflows — approvals, stock lookups, field reporting — in the hands of staff who never open a desktop.',
    tags: ['Flutter', 'ERPNext', 'Offline-first'],
    metrics: [
      { k: 'Platforms', v: 'iOS + Android' },
      { k: 'Role', v: 'Lead developer' },
    ],
    links: { live: '', repo: '' },
    accent: '#22d3ee',
    placeholder: true,
  },
  {
    title: 'Education CRM Platform',
    subtitle: 'Flutter · Node.js · MySQL',
    year: '2025',
    blurb:
      'Counsellor-facing application for managing student applications end to end, from enquiry through offer, built for a consulting workflow.',
    tags: ['Flutter', 'Node.js', 'MySQL'],
    metrics: [
      { k: 'Team', v: 'Scrum, 6 devs' },
      { k: 'Role', v: 'Flutter developer' },
    ],
    links: { live: '', repo: '' },
    accent: '#8b5cf6',
    placeholder: true,
  },
  {
    title: 'Inventory & Billing Suite',
    subtitle: 'React · Node.js · SQL',
    year: '2024',
    blurb:
      'Web dashboard for stock movement, invoicing and reporting, with an ORM layer designed for fast aggregate queries.',
    tags: ['React', 'Node.js', 'ORM'],
    metrics: [
      { k: 'Scope', v: 'Full-stack' },
      { k: 'Role', v: 'Developer' },
    ],
    links: { live: '', repo: '' },
    accent: '#f472b6',
    placeholder: true,
  },
  {
    title: 'Your next project',
    subtitle: 'Add it in src/data/content.js',
    year: '2026',
    blurb:
      'Swap this card out for real work — a case study reads far better than a feature list. One paragraph on the problem, one on what you built.',
    tags: ['TODO'],
    metrics: [{ k: 'Status', v: 'Placeholder' }],
    links: { live: '', repo: '' },
    accent: '#a3e635',
    placeholder: true,
  },
]

/* -------------------------------------------------------------- testimonials */
/* TODO: replace with real quotes — ideally lifted from your LinkedIn
   recommendations, with the person's actual name, title and company. */
export const testimonials = [
  {
    quote:
      'Placeholder quote — paste a real recommendation here. Short, specific quotes about how someone works land much harder than generic praise.',
    name: 'Name Surname',
    title: 'Engineering Manager',
    company: 'Company',
    placeholder: true,
  },
  {
    quote:
      'Placeholder quote — a line from a manager or client about a shipped project, with the outcome mentioned, is the strongest version of this section.',
    name: 'Name Surname',
    title: 'Product Owner',
    company: 'Company',
    placeholder: true,
  },
  {
    quote:
      'Placeholder quote — if you have no written recommendations yet, ask two former colleagues on LinkedIn. It takes them five minutes.',
    name: 'Name Surname',
    title: 'Senior Developer',
    company: 'Company',
    placeholder: true,
  },
]

/* ------------------------------------------------------------------- contact */
export const contact = {
  email: 'manikandan.r@bontonsoftwares.com', // TODO update to your current address
  phone: '', // TODO optional, e.g. '+91 90000 00000'
  resume: '/Manikandan-R-Resume.pdf', // TODO drop your PDF into /public with this name
  socials: [
    { label: 'LinkedIn', href: 'https://www.linkedin.com/in/manikandan-r-flutter/', handle: '/in/manikandan-r-flutter' },
    { label: 'GitHub', href: '', handle: 'add your GitHub' }, // TODO
    { label: 'Email', href: 'mailto:manikandan.r@bontonsoftwares.com', handle: 'say hello' },
  ],
}

export const nav = [
  { id: 'home', label: 'Home' },
  { id: 'about', label: 'About' },
  { id: 'work', label: 'Experience' },
  { id: 'projects', label: 'Projects' },
  { id: 'skills', label: 'Skills' },
  { id: 'voices', label: 'Voices' },
  { id: 'contact', label: 'Contact' },
]
