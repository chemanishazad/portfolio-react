import { Suspense, useRef } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, AdaptiveDpr, Preload } from '@react-three/drei'
import {
  EffectComposer,
  Bloom,
  ChromaticAberration,
  Vignette,
  Noise,
} from '@react-three/postprocessing'
import { BlendFunction } from 'postprocessing'
import * as THREE from 'three'

import Starfield from './Starfield'
import Core from './Core'
import Shards from './Shards'
import { perf, pointerState, prefersReducedMotion, scrollState } from '../lib/state'

/** Scroll- and pointer-driven camera. Nothing here causes a React render. */
function CameraRig() {
  const { camera } = useThree()
  const target = useRef(new THREE.Vector3(0, 0, 0))

  useFrame((state, dt) => {
    const d = Math.min(dt, 0.05)
    const h = Math.min(1, scrollState.hero)
    const narrow = state.viewport.aspect < 1.05

    // Pull back through the hero, then hold: past the fold the canvas is
    // ambient depth, not the subject.
    const wantZ = (narrow ? 9.6 : 7.4) + h * 4.5
    const wantY = h * 1.4
    const wantX = pointerState.x * (narrow ? 0.3 : 0.9)

    camera.position.z += (wantZ - camera.position.z) * (1 - Math.pow(0.002, d))
    camera.position.y += (wantY - camera.position.y) * (1 - Math.pow(0.005, d))
    camera.position.x += (wantX - camera.position.x) * (1 - Math.pow(0.01, d))

    target.current.set(narrow ? 0 : 0.8, h * 1.1, 0)
    camera.lookAt(target.current)
  })

  return null
}

function SceneContents() {
  const tier = perf.tier

  return (
    <>
      <color attach="background" args={['#04050a']} />
      <fog attach="fog" args={['#04050a', 12, 46]} />

      <ambientLight intensity={0.28} />
      <pointLight position={[6, 5, 6]} intensity={90} color="#22d3ee" distance={30} decay={2} />
      <pointLight position={[-7, -4, 4]} intensity={70} color="#8b5cf6" distance={30} decay={2} />
      <pointLight position={[0, 6, -6]} intensity={40} color="#f472b6" distance={30} decay={2} />

      {/* Procedural environment map — built in-engine, no HDRI download. */}
      <Environment resolution={tier === 'low' ? 64 : 128} frames={1}>
        <mesh scale={60}>
          <sphereGeometry args={[1, 24, 24]} />
          <meshBasicMaterial color="#05060c" side={THREE.BackSide} />
        </mesh>
        <Lightformer intensity={2.4} color="#22d3ee" position={[0, 4, -6]} scale={[10, 3, 1]} />
        <Lightformer intensity={1.8} color="#8b5cf6" position={[-6, -2, 4]} scale={[8, 4, 1]} />
        <Lightformer intensity={1.1} color="#f472b6" position={[6, 1, 3]} scale={[6, 3, 1]} />
      </Environment>

      <Starfield tier={tier} />
      <Core tier={tier} />
      <Shards tier={tier} />

      <CameraRig />
      <AdaptiveDpr pixelated />
      <Preload all />

      {tier !== 'low' && (
        <EffectComposer multisampling={0} disableNormalPass>
          <Bloom
            intensity={1.15}
            luminanceThreshold={0.16}
            luminanceSmoothing={0.35}
            mipmapBlur
            radius={0.72}
          />
          <ChromaticAberration
            offset={new THREE.Vector2(0.0008, 0.0012)}
            blendFunction={BlendFunction.NORMAL}
          />
          <Noise premultiply blendFunction={BlendFunction.SOFT_LIGHT} opacity={0.35} />
          <Vignette eskil={false} offset={0.22} darkness={0.85} />
        </EffectComposer>
      )}
    </>
  )
}

export default function Scene() {
  // Reduced-motion visitors get a still, cheap gradient instead of a canvas.
  if (prefersReducedMotion) {
    return (
      <div
        aria-hidden
        className="pointer-events-none fixed inset-0 -z-10"
        style={{
          background:
            'radial-gradient(ellipse 70% 50% at 50% 32%, rgba(34,211,238,0.16), transparent 60%), radial-gradient(ellipse 60% 50% at 78% 70%, rgba(139,92,246,0.14), transparent 62%), #04050a',
        }}
      />
    )
  }

  return (
    <div className="pointer-events-none fixed inset-0 -z-10">
      <Canvas
        dpr={[1, perf.tier === 'high' ? 1.7 : 1.25]}
        camera={{ position: [0, 0, 7.4], fov: 46, near: 0.1, far: 90 }}
        gl={{
          antialias: false,
          powerPreference: 'high-performance',
          alpha: false,
          stencil: false,
          depth: true,
        }}
        onCreated={({ gl }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping
          gl.toneMappingExposure = 1.05
        }}
      >
        <Suspense fallback={null}>
          <SceneContents />
        </Suspense>
      </Canvas>
    </div>
  )
}
