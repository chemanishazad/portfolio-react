import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Icosahedron, Torus, MeshDistortMaterial } from '@react-three/drei'
import * as THREE from 'three'
import { pointerState, scrollState } from '../lib/state'

/**
 * The centrepiece: a distorting dark core inside a glowing wireframe cage,
 * wrapped by three tilted rings. Everything is procedural — no assets.
 */
export default function Core({ tier = 'high' }) {
  const group = useRef()
  const cage = useRef()
  const ringA = useRef()
  const ringB = useRef()
  const ringC = useRef()

  const detail = tier === 'low' ? 1 : 2
  const seg = tier === 'low' ? [40, 6] : [128, 16]

  const rings = useMemo(
    () => [
      { ref: ringA, r: 2.5, tube: 0.012, rot: [Math.PI / 2.2, 0, 0], color: '#22d3ee', speed: 0.18 },
      { ref: ringB, r: 3.1, tube: 0.009, rot: [Math.PI / 3, Math.PI / 5, 0], color: '#8b5cf6', speed: -0.13 },
      { ref: ringC, r: 3.7, tube: 0.007, rot: [Math.PI / 1.7, -Math.PI / 6, 0], color: '#f472b6', speed: 0.09 },
    ],
    []
  )

  useFrame((state, dt) => {
    const d = Math.min(dt, 0.05)
    const t = state.clock.elapsedTime
    const g = group.current
    if (!g) return

    // Pointer-follow tilt, eased.
    g.rotation.y += (pointerState.x * 0.35 - g.rotation.y) * 0.05
    g.rotation.x += (pointerState.y * 0.25 - g.rotation.x) * 0.05

    // Sit to the side of the headline on wide screens; centre it on narrow ones.
    const aspect = state.viewport.aspect
    const wide = aspect > 1.05
    const restX = wide ? 2.5 : 0
    const restY = wide ? 0.1 : 1.1

    // Leave the frame once the visitor is past the hero so it never fights
    // with the content sections. `hero` is 0..1 across the first viewport.
    const h = Math.min(1, scrollState.hero)
    const ease = h * h

    g.position.x += (restX - g.position.x) * 0.06
    g.position.y = restY + 0.15 * Math.sin(t * 0.5) + ease * 9
    const base = wide ? 1 : 0.72
    g.scale.setScalar(base * (1 - ease * 0.45))

    if (cage.current) {
      cage.current.rotation.y += d * 0.14
      cage.current.rotation.z -= d * 0.05
    }
    rings.forEach(({ ref, speed }) => {
      if (ref.current) ref.current.rotation.z += d * speed
    })
  })

  return (
    <group ref={group}>
      {/* inner morphing core */}
      <mesh>
        <sphereGeometry args={[1.35, seg[0], seg[0] / 2]} />
        <MeshDistortMaterial
          color="#0a0f1f"
          emissive="#0e7490"
          emissiveIntensity={0.35}
          roughness={0.15}
          metalness={0.9}
          distort={0.36}
          speed={1.4}
        />
      </mesh>

      {/* glowing wireframe cage */}
      <Icosahedron ref={cage} args={[2.05, detail]}>
        <meshBasicMaterial
          color="#22d3ee"
          wireframe
          transparent
          opacity={0.16}
          blending={THREE.AdditiveBlending}
          depthWrite={false}
        />
      </Icosahedron>

      {/* faint outer shell for silhouette */}
      <Icosahedron args={[2.06, detail]}>
        <meshBasicMaterial color="#0b1020" transparent opacity={0.12} side={THREE.BackSide} />
      </Icosahedron>

      {/* orbit rings */}
      {rings.map(({ ref, r, tube, rot, color }, i) => (
        <Torus key={i} ref={ref} args={[r, tube, 8, seg[0]]} rotation={rot}>
          <meshBasicMaterial
            color={color}
            transparent
            opacity={0.42}
            blending={THREE.AdditiveBlending}
            depthWrite={false}
          />
        </Torus>
      ))}
    </group>
  )
}
