import { useMemo, useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { Float, RoundedBox } from '@react-three/drei'
import { scrollState } from '../lib/state'

/**
 * Floating glass slabs. Deliberately fake glass (transparent physical
 * material + emissive rim) rather than real transmission, which costs an
 * extra render pass per frame for very little visual gain at this scale.
 */
const SHARDS = [
  { p: [-4.4, 1.7, -1.2], r: [0.4, 0.7, -0.25], s: [1.5, 2.0, 0.07], c: '#22d3ee' },
  { p: [4.6, -1.2, -0.6], r: [-0.3, -0.6, 0.2], s: [1.8, 1.2, 0.07], c: '#8b5cf6' },
  { p: [-3.2, -2.3, 1.4], r: [0.2, 0.4, 0.5], s: [1.1, 1.1, 0.06], c: '#f472b6' },
  { p: [3.4, 2.4, 1.1], r: [-0.5, 0.3, -0.4], s: [1.0, 1.4, 0.06], c: '#67e8f9' },
  { p: [0.4, -3.4, -2.4], r: [0.9, 0.2, 0.1], s: [2.2, 1.0, 0.07], c: '#a78bfa' },
  { p: [-6.0, -0.4, -3.0], r: [0.1, -0.9, 0.3], s: [1.3, 1.7, 0.06], c: '#38bdf8' },
]

export default function Shards({ tier = 'high' }) {
  const list = useMemo(() => (tier === 'low' ? SHARDS.slice(0, 3) : SHARDS), [tier])
  const group = useRef()

  useFrame(() => {
    const g = group.current
    if (!g) return
    // Sink and fade back as the hero scrolls away.
    const h = Math.min(1, scrollState.hero)
    g.position.y = -h * h * 7
    g.position.z = -h * 4
  })

  return (
    <group ref={group}>
      {list.map((s, i) => (
        <Float
          key={i}
          speed={1.1 + i * 0.16}
          rotationIntensity={0.35}
          floatIntensity={0.85}
          floatingRange={[-0.25, 0.25]}
        >
          <RoundedBox position={s.p} rotation={s.r} args={s.s} radius={0.03} smoothness={3}>
            <meshPhysicalMaterial
              color="#0d1424"
              emissive={s.c}
              emissiveIntensity={0.18}
              roughness={0.08}
              metalness={0.25}
              transparent
              opacity={0.42}
              clearcoat={1}
              clearcoatRoughness={0.08}
              envMapIntensity={1.4}
            />
          </RoundedBox>
        </Float>
      ))}
    </group>
  )
}
