import Section from './Section'
import Reveal from './Reveal'
import { about, profile } from '../data/content'

export default function About() {
  return (
    <Section
      id="about"
      eyebrow="About"
      title={<>Design instinct,<br />engineering discipline.</>}
    >
      <div className="grid gap-12 lg:grid-cols-[1.35fr_1fr]">
        <div className="space-y-6">
          <Reveal>
            <p className="text-lg leading-relaxed text-white/75 md:text-xl">{about.intro}</p>
          </Reveal>
          {about.body.map((p, i) => (
            <Reveal key={i} delay={0.08 + i * 0.06}>
              <p className="leading-relaxed text-white/50">{p}</p>
            </Reveal>
          ))}
        </div>

        <div className="space-y-4">
          <Reveal delay={0.1}>
            <div className="glass glass-hover rounded-2xl p-6">
              <span className="eyebrow">Currently</span>
              <p className="mt-3 font-display text-xl font-medium text-white">{profile.role}</p>
              <p className="mt-1 text-sm text-white/50">{profile.company}</p>
              <div className="mt-5 h-px w-full bg-white/[0.07]" />
              <p className="mt-5 text-sm leading-relaxed text-white/45">
                Working across Flutter, React, Node.js and Frappe/ERPNext — front-end through
                data model.
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.18}>
            <div className="glass glass-hover rounded-2xl p-6">
              <span className="eyebrow">How I work</span>
              <ul className="mt-4 space-y-3 text-sm text-white/55">
                {[
                  'Model the data before drawing the screen.',
                  'Ship in vertical slices, not layers.',
                  'Treat the design as a spec, not a suggestion.',
                  'Leave the codebase easier to change than I found it.',
                ].map((t) => (
                  <li key={t} className="flex gap-3">
                    <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-neon-cyan" />
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </Section>
  )
}
