import { motion } from 'framer-motion'

const EASE = [0.16, 1, 0.3, 1]

export default function Reveal({
  children,
  delay = 0,
  y = 26,
  x = 0,
  duration = 0.75,
  once = true,
  className = '',
  as = 'div',
}) {
  const M = motion[as] || motion.div
  return (
    <M
      className={className}
      initial={{ opacity: 0, y, x, filter: 'blur(6px)' }}
      whileInView={{ opacity: 1, y: 0, x: 0, filter: 'blur(0px)' }}
      viewport={{ once, margin: '-12% 0px -12% 0px' }}
      transition={{ duration, delay, ease: EASE }}
    >
      {children}
    </M>
  )
}

/** Stagger container + item pair for lists of cards. */
export const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.05 } },
}

export const staggerItem = {
  hidden: { opacity: 0, y: 28, filter: 'blur(6px)' },
  show: { opacity: 1, y: 0, filter: 'blur(0px)', transition: { duration: 0.7, ease: EASE } },
}
