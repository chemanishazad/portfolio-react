import { useRef, useState } from 'react'
import { motion } from 'framer-motion'
import Section from './Section'
import { projects } from '../data/content'
import { stagger, staggerItem } from './Reveal'

/** Card that tilts toward the pointer in 3D and lights a follow spotlight. */
function Card({ p }) {
  const ref = useRef(null)
  const [style, setStyle] = useState({})
  const [glow, setGlow] = useState({ x: '50%', y: '0%' })

  const onMove = (e) => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const px = (e.clientX - r.left) / r.width
    const py = (e.clientY - r.top) / r.height
    setStyle({
      transform:
        'perspective(900px) rotateY(' +
        ((px - 0.5) * 9).toFixed(2) +
        'deg) rotateX(' +
        ((0.5 - py) * 9).toFixed(2) +
        'deg) translateY(-6px)',
    })
    setGlow({ x: (px * 100).toFixed(1) + '%', y: (py * 100).toFixed(1) + '%' })
  }

  const onLeave = () => {
    setStyle({ transform: 'perspective(900px) rotateY(0deg) rotateX(0deg) translateY(0)' })
    setGlow({ x: '50%', y: '0%' })
  }

  return (
    <motion.article
      variants={staggerItem}
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={onLeave}
      style={style}
      data-cursor="grow"
      className="glass group relative overflow-hidden rounded-3xl p-7 transition-[transform,border-color,box-shadow] duration-300 will-change-transform hover:border-white/20 md:p-8"
    >
      {/* pointer spotlight */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background:
            'radial-gradient(420px circle at ' + glow.x + ' ' + glow.y + ', ' + p.accent + '22, transparent 70%)',
        }}
      />
      {/* accent edge */}
      <span
        aria-hidden
        className="absolute left-0 top-0 h-full w-[2px] opacity-60"
        style={{ background: 'linear-gradient(to bottom, ' + p.accent + ', transparent)' }}
      />

      <div className="relative">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-2xl font-semibold tracking-tight text-white">
              {p.title}
            </h3>
            <p className="mt-1.5 font-mono text-[11px] uppercase tracking-[0.16em]" style={{ color: p.accent }}>
              {p.subtitle}
            </p>
          </div>
          <span className="shrink-0 font-mono text-[11px] text-white/30">{p.year}</span>
        </div>

        {p.placeholder && (
          <span className="mt-4 inline-block rounded-full border border-amber-400/30 bg-amber-400/10 px-2.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-amber-300/80">
            placeholder — edit content.js
          </span>
        )}

        <p className="mt-4 text-[15px] leading-relaxed text-white/55">{p.blurb}</p>

        {p.metrics?.length > 0 && (
          <div className="mt-6 flex flex-wrap gap-x-8 gap-y-3 border-t border-white/[0.07] pt-5">
            {p.metrics.map((m) => (
              <div key={m.k}>
                <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-white/30">
                  {m.k}
                </div>
                <div className="mt-0.5 text-sm text-white/75">{m.v}</div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {p.tags.map((t) => (
              <span
                key={t}
                className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 font-mono text-[10.5px] text-white/55"
              >
                {t}
              </span>
            ))}
          </div>
          <div className="flex gap-4">
            {p.links?.live && (
              <a href={p.links.live} target="_blank" rel="noreferrer" className="text-sm text-white/70 underline decoration-white/20 underline-offset-4 hover:text-neon-cyan">
                Live ↗
              </a>
            )}
            {p.links?.repo && (
              <a href={p.links.repo} target="_blank" rel="noreferrer" className="text-sm text-white/70 underline decoration-white/20 underline-offset-4 hover:text-neon-cyan">
                Code ↗
              </a>
            )}
          </div>
        </div>
      </div>
    </motion.article>
  )
}

export default function Projects() {
  return (
    <Section
      id="projects"
      eyebrow="Selected work"
      title="Things I've built."
      lead="Cross-platform apps and the systems behind them. Replace these cards with your real case studies in src/data/content.js."
    >
      <motion.div
        variants={stagger}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, margin: '-10%' }}
        className="grid gap-6 md:grid-cols-2"
      >
        {projects.map((p) => (
          <Card key={p.title} p={p} />
        ))}
      </motion.div>
    </Section>
  )
}
