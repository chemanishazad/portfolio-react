# Manikandan R — 3D Portfolio

A dark, cinematic single-page portfolio built with **React + Vite + React Three Fiber**.
The 3D background (particle field, distorting core, orbit rings, floating glass slabs,
bloom + chromatic aberration) is fully procedural — there are no model or texture files
to download.

## Run it

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build into /dist
npm run preview  # serve the built output locally
```

Node 18+ required (built and tested on Node 22).

## Edit your content — one file

**All text, jobs, skills, projects, testimonials and links live in
`src/data/content.js`.** You should not need to touch any component to keep the site
current. Anything marked `// TODO` in that file is a placeholder.

Priority list:

1. `projects` — replace all four placeholder cards with real work.
2. `testimonials` — paste real LinkedIn recommendations (name, title, company).
3. `contact.email` — currently your Bonton address; update to your current one.
4. `contact.socials` — add your GitHub URL.
5. `experience[].highlights` — make the bullet points specific (numbers, scale, outcomes).

## Résumé download

Drop your PDF into `public/` named exactly:

```
public/Manikandan-R-Resume.pdf
```

The nav button, hero button and contact card all point at it via `contact.resume`.
Until the file exists, those buttons 404 — that is the only thing on the page that
needs a file from you.

## Project structure

```
src/
  data/content.js       ← everything you edit
  lib/state.js          ← non-reactive scroll/pointer state + device tier detection
  three/
    Scene.jsx           ← Canvas, lights, procedural env map, postprocessing, camera rig
    Starfield.jsx       ← three parallax particle layers
    Core.jsx            ← distorting core, wireframe cage, orbit rings
    Shards.jsx          ← floating glass slabs
  components/           ← Nav, Hero, About, Experience, Projects, Skills,
                          Testimonials, Contact, Footer, Loader, Cursor, Marquee
```

## Performance notes

- `lib/state.js` detects a device tier from CPU cores / memory / touch and scales
  particle counts; postprocessing is switched off entirely on the low tier.
- Scroll and pointer values are kept in plain module state, so moving the mouse or
  scrolling never triggers a React re-render — only the r3f loop reads them.
- `prefers-reduced-motion` replaces the whole canvas with a static gradient.
- The environment map is generated in-engine (drei `<Environment>` with
  `<Lightformer>` children) so nothing is fetched at runtime except Google Fonts.

## Deploy

Any static host. The build output is `/dist` and `base` is set to `./`, so it works
from a subpath too.

- **Vercel / Netlify** — connect the repo, build command `npm run build`, output `dist`.
- **GitHub Pages** — push `dist` to `gh-pages`.

## Customising the look

- Colours: `tailwind.config.js` (`neon.*`, `ink.*`) and the `--cyan/--violet/--pink`
  variables in `src/index.css`.
- Scene intensity: `Bloom intensity` and `ChromaticAberration offset` in
  `src/three/Scene.jsx`.
- Camera travel on scroll: the `wantZ` / `wantY` values in `CameraRig`.
